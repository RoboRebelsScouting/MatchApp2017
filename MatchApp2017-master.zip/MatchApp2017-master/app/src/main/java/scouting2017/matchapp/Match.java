package scouting2017.matchapp;

/**
 * Created by 1153 on 4/10/2017.
 */

public class Match {
    public int matchNumber;
    public int red1;
    public int red2;
    public int red3;
    public int blue1;
    public int blue2;
    public int blue3;
}
