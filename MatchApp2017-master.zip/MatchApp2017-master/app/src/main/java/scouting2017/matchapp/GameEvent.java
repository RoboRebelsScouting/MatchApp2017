package scouting2017.matchapp;

/**
 * Created by mcgrathg19 on 1/21/2017.
 */

public class GameEvent {
    public String eventType ;
    public String eventValue ;
    public Long eventTime ;
}
