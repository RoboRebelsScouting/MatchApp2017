package scouting2017.matchapp;

/**
 * Created by mcgrathg19 on 2/12/2017.
 */

public class SubEvent {
    public String eventType ;
    public String eventValue ;
    public Long eventTime ;
}
