package scouting2017.matchapp;

import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by makke on 12/5/2017.
 */

import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class BluetoothStatusActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);

    }
}